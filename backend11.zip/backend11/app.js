const express = require('express')
const app = express()
const dotenv = require('dotenv').config()
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcrypt') 
const cors = require('cors')
const path = require('path')
const  databseConnnection  = require('./db.steup.js')
const  isUserAuthenticated = require('./middleware/isUserAuthenticated.js')
const userRouter = require("./routes/user.router.js")
const postRouter = require("./routes/post.route.js")
const UserModel = require('./models/User.model.js')
const postModel = require('./models/post.model.js')

// MIDDLEWERES 
app.use(cors({
  origin : 'http://localhost:5173',
  credentials : true
}))
app.use(bodyParser.urlencoded({extended : true}))
app.use(bodyParser.json())
app.use("/uploads",express.static(path.join(__dirname,'uploads')))
app.use(cookieParser())



// ROUTES 
app.use("/api/v1/user",userRouter)
app.use("/api/v1/post", postRouter)
app.get('/api/v1/userData',isUserAuthenticated, (req,res)=> {
  res.json({
    user : req.user
  })
})
app.get('/api/v1/posts',isUserAuthenticated,async(req,res)=> {
  let allpost = await postModel.find().populate('author')
  allpost.reverse()
  res.json({
    posts : allpost
  })
})
app.get('/api/v1/users',isUserAuthenticated,async(req,res)=> {
  const allUsers = await UserModel.find().select('-password')
  res.json({
    allUsers
  })
})
// SEARCHING USER BY ID 
app.get('/api/v1/getUser/:id',async(req,res)=> {
  const allUser = await UserModel.findOne({_id : req.params.id}).populate("post")
  res.json({
    users : allUser
  })
})
// SEARCHING POST BY ID 
app.get('/api/v1/getPost/:id',async(req,res)=> {
  const allPosts = await postModel.find({_id : req.params.id}).populate("author")
  res.json({
    post : allPosts
  })
})

// DATABSE CONNECTION AND SERVER RESTART 
try {
  const PORT = process.env.PORT
  app.listen(PORT,async()=> {
   await databseConnnection()
    console.log('Server is ruuning at', PORT)
  })
} catch (error) {
  console.log(error)
}