const postModel = require("../models/post.model")
const userModel = require("../models/User.model")
// FUNCTION FOR UPLOADING POST 
const uploadPost = async(req,res)=> {
    const {title,dipscription} = req.body
    const file = req.file
    console.log(file)
    const newPost = await postModel.create({
        title ,
        dipscription,
        author : req.user._id ,
        image : `http://localhost:3000/${file.path}`,
    })
    // Adding into users post array 
    const author = await userModel.findOne({email : req.user.email})
    console.log(author)
    author.post.push(newPost._id)
     author.save()
    // sending response 
    res.json({
        createdPost : newPost
    })
}

module.exports = uploadPost