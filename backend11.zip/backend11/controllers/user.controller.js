const UserModel = require("../models/User.model")
const postModel = require("../models/post.model")
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')



// USER REGISTRATION FUNCTION 
const registerUser = (req,res)=> {
  const {firstName, lastName,userName,email,password} = req.body
  const profileImage = req.file
  console.log(profileImage)
  try {
     // making salt  
  bcrypt.genSalt(15,(error,salt)=> {
    //  hashing password 
    bcrypt.hash(password,salt,async(error,hasedPassword)=> {
      const newUser = await UserModel.create({
        firstName,
        lastName,
        userName,
        email,
        password : hasedPassword,
        profileImage : `http://localhost:3000/${profileImage.path}`,
      })
     return res.json({
        messege : 201, 
        sucess : true,
        message : "User has been registered!",
        user : newUser
      })
    }) 
    })
  } catch (error) {
   return res.json({
      messege : 401,
      sucess : false,
      message : "Internal server error! please try again later",
      error
    })
  }
}



// USER LOGIN FUNCTION 
 const loginUser = async(req,res)=> {
  console.log(req.body)
  const {userName, password} = req.body
  try {
    // cheching if user exist or not 
    const userForLoginProcess = await UserModel.findOne({userName})
    if(!userForLoginProcess) {
     return res.json({
        status : 404,
        sucess : false,
        message : "User not found"
      })
    }
    // if user exist password checking 
    const isPasswordRight = await bcrypt.compare(password,userForLoginProcess.password)
    if(!isPasswordRight) {
      return res.json({
        status : 401,
        sucess : false,
        message : "Username or password is wrong!",
      })
    }
    else {
    // making setting cookie for client 
    const token = jwt.sign({username : userName,}, process.env.JWT_SECREAT)
    const user = await UserModel.findOne({userName}).select("-password").populate('post')
    res.cookie("token", token)
      res.json({
        status : 200,
        sucess : true,
        message : "User has been logged in!",
        user 
      })
    }
  } catch (error) {
    // sending response 
    res.json({
      status : 401,
      sucess : false,
      message : "Internal server error! please try again later",
      error
    })
  }
}



module.exports = {registerUser, loginUser}