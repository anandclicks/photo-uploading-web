const mongoose  = require("mongoose");

const databseConnnection = async()=> {
  try {
    const DBCONNECTION_URL = process.env.DBCONNECTION_URL
   await mongoose.connect(DBCONNECTION_URL).then(()=> console.log('Datsbse has connected..'))
  } catch (error) {
    console.log(error)
  }
}


module.exports =  databseConnnection