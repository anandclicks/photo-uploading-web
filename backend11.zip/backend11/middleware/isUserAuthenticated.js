const jwt = require('jsonwebtoken')
const UserModel = require('../models/User.model')
const cookieParser = require('cookie-parser')
const express = require('express')
const app = express()


app.use(cookieParser())


const isUserAuthenticated = async(req,res,next)=> {
 try {
  const cookie = req.cookies.token
  if(!cookie){
    res.json({
      success : false,  
      status : 401,
      messeg : "User is not logged in or  unauthorized"
    })
    return ;
  }
  else {
    const loggedInUserCredentiols= jwt.verify(cookie,process.env.JWT_SECREAT)
    const loggedInUserDetails = await UserModel.findOne({userName : loggedInUserCredentiols.username}).select("-password")
    if(!loggedInUserDetails) {
      res.json({
        success : false,
        status : 404,
        messege : "Internal server error"
      })
    }
    else {
      req.user = await loggedInUserDetails.populate('post')
      next()
    }
  }
 } catch (error) {
  console.log(error)
  next()
 }
}


module.exports = isUserAuthenticated