const multer = require('multer')
const path = require('path')

// FILE UPLOADING CONFIGRATION 
const storage = multer.diskStorage({
  destination : (req,file,cb)=> {
    const finalDestination = path.join('uploads')
    cb(null, finalDestination)
  },
  filename : (req,file,cb)=> {
    const finalFilename = `${Date.now()}_anandclicks.jpg`
    cb(null,finalFilename)
  }
})
const uplaod = multer({storage})

module.exports = uplaod
