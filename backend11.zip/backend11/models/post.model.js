const mongoose = require('mongoose')


const postModel = new mongoose.Schema({
  title : {
    type : String,
  },
  dipscription : {
    type : String,
    required : true
  },
  image : {
    type : String,
    required : true
  },
  author : {
    type : mongoose.Schema.Types.ObjectId,
    ref : 'userModel'
  },
  likes : [
    {
      type : mongoose.Schema.Types.ObjectId,
      ref : 'user'
    }
  ],
})


module.exports = mongoose.model("postModel", postModel)