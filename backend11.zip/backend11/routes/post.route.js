const express = require("express")
const isUserAuthenticated = require("../middleware/isUserAuthenticated")
const router = express.Router()
const upload = require("../middleware/multer")


// IMPORTING CONTROLLERS 
const uploadPost = require("../controllers/post.controller")

// HANDLING CONTROLLERS 
router.post("/cratePost",isUserAuthenticated,upload.single('image'),uploadPost)




module.exports = router