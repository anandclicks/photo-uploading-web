const express = require('express')
const router = express.Router()


// IMPRTING CONTROLLERS 
const {registerUser, loginUser} = require('../controllers/user.controller.js')
const uplaod = require('../middleware/multer.js')


// USER CONTROLLERS HANDLING 
router.post('/registration',uplaod.single("image"),registerUser)
router.post('/login',uplaod.none(),loginUser)


module.exports = router